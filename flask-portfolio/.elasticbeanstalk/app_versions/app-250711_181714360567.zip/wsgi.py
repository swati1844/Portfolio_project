from app import application  # or from app import app as application
